export const USER_ROLE = {
  ADMIN: "ADMIN",
  USER: "USER",
} as const;

export const USER_STATUS = {
  IN_PROGRESS: "IN_PROGRESS",
  BLOCKED: "BLOCKED",
} as const;
