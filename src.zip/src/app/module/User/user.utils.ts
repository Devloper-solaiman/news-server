export const UserSearchableFields = ["name", "email", "country", "address"];
