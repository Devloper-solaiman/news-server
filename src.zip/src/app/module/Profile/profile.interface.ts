export interface TUpdateUser {
  name: string;
  email: string;
  image?: string;
  flower: number;
  flowing: number;
  country?: string;
  address?: string;
}
